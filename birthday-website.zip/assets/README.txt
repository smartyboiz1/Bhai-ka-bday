Put your real files in this folder using these exact names
(or edit the paths in script.js under the CUSTOMIZATION section
if you'd rather use different names):

  class8.jpg            - your Class 8 handshake photo (Screen 3)
  friend-photo.jpg      - a small profile picture (Screen 3 avatar)
  birthday-voice.mp3    - your voice note / birthday message (Screen 3 audio player)

Optional extras (referenced in the EXTRA_PHOTOS array in script.js):
  extra1.jpg, extra2.jpg, ... - shown as little polaroids on the final screen

You don't need to touch any HTML or CSS. Until a file exists here,
the website shows a cute placeholder in its place instead of breaking.
